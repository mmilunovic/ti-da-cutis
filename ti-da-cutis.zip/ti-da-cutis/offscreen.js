var __defProp = Object.defineProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// node_modules/onnxruntime-web/dist/ort.wasm.bundle.min.mjs
var ort_wasm_bundle_min_exports = {};
__export(ort_wasm_bundle_min_exports, {
  InferenceSession: () => Ln,
  TRACE: () => Dt,
  TRACE_FUNC_BEGIN: () => J,
  TRACE_FUNC_END: () => Z,
  Tensor: () => W,
  default: () => vo,
  env: () => I,
  registerBackend: () => ce
});
var He = Object.defineProperty;
var An = Object.getOwnPropertyDescriptor;
var On = Object.getOwnPropertyNames;
var In = Object.prototype.hasOwnProperty;
var je = ((e) => typeof __require < "u" ? __require : typeof Proxy < "u" ? new Proxy(e, { get: (t, n) => (typeof __require < "u" ? __require : t)[n] }) : e)(function(e) {
  if (typeof __require < "u") return __require.apply(this, arguments);
  throw Error('Dynamic require of "' + e + '" is not supported');
});
var E = (e, t) => () => (e && (t = e(e = 0)), t);
var Ve = (e, t) => {
  for (var n in t) He(e, n, { get: t[n], enumerable: true });
};
var Pn = (e, t, n, o) => {
  if (t && typeof t == "object" || typeof t == "function") for (let r of On(t)) !In.call(e, r) && r !== n && He(e, r, { get: () => t[r], enumerable: !(o = An(t, r)) || o.enumerable });
  return e;
};
var lt = (e) => Pn(He({}, "__esModule", { value: true }), e);
var be;
var Y;
var ce;
var xn;
var pt;
var Ye = E(() => {
  "use strict";
  be = /* @__PURE__ */ new Map(), Y = [], ce = (e, t, n) => {
    if (t && typeof t.init == "function" && typeof t.createInferenceSessionHandler == "function") {
      let o = be.get(e);
      if (o === void 0) be.set(e, { backend: t, priority: n });
      else {
        if (o.priority > n) return;
        if (o.priority === n && o.backend !== t) throw new Error(`cannot register backend "${e}" using priority ${n}`);
      }
      if (n >= 0) {
        let r = Y.indexOf(e);
        r !== -1 && Y.splice(r, 1);
        for (let i = 0; i < Y.length; i++) if (be.get(Y[i]).priority <= n) {
          Y.splice(i, 0, e);
          return;
        }
        Y.push(e);
      }
      return;
    }
    throw new TypeError("not a valid backend");
  }, xn = async (e) => {
    let t = be.get(e);
    if (!t) return "backend not found.";
    if (t.initialized) return t.backend;
    if (t.aborted) return t.error;
    {
      let n = !!t.initPromise;
      try {
        return n || (t.initPromise = t.backend.init(e)), await t.initPromise, t.initialized = true, t.backend;
      } catch (o) {
        return n || (t.error = `${o}`, t.aborted = true), t.error;
      } finally {
        delete t.initPromise;
      }
    }
  }, pt = async (e) => {
    let t = e.executionProviders || [], n = t.map((u) => typeof u == "string" ? u : u.name), o = n.length === 0 ? Y : n, r, i = [], a = /* @__PURE__ */ new Set();
    for (let u of o) {
      let f = await xn(u);
      typeof f == "string" ? i.push({ name: u, err: f }) : (r || (r = f), r === f && a.add(u));
    }
    if (!r) throw new Error(`no available backend found. ERR: ${i.map((u) => `[${u.name}] ${u.err}`).join(", ")}`);
    for (let { name: u, err: f } of i) n.includes(u) && console.warn(`removing requested execution provider "${u}" from session options because it is not available: ${f}`);
    let s = t.filter((u) => a.has(typeof u == "string" ? u : u.name));
    return [r, new Proxy(e, { get: (u, f) => f === "executionProviders" ? s : Reflect.get(u, f) })];
  };
});
var mt = E(() => {
  "use strict";
  Ye();
});
var wt;
var ht = E(() => {
  "use strict";
  wt = "1.22.0";
});
var yt;
var C;
var qe = E(() => {
  "use strict";
  ht();
  yt = "warning", C = { wasm: {}, webgl: {}, webgpu: {}, versions: { common: wt }, set logLevel(e) {
    if (e !== void 0) {
      if (typeof e != "string" || ["verbose", "info", "warning", "error", "fatal"].indexOf(e) === -1) throw new Error(`Unsupported logging level: ${e}`);
      yt = e;
    }
  }, get logLevel() {
    return yt;
  } };
  Object.defineProperty(C, "logLevel", { enumerable: true });
});
var I;
var bt = E(() => {
  "use strict";
  qe();
  I = C;
});
var gt;
var Et;
var Tt = E(() => {
  "use strict";
  gt = (e, t) => {
    let n = typeof document < "u" ? document.createElement("canvas") : new OffscreenCanvas(1, 1);
    n.width = e.dims[3], n.height = e.dims[2];
    let o = n.getContext("2d");
    if (o != null) {
      let r, i;
      t?.tensorLayout !== void 0 && t.tensorLayout === "NHWC" ? (r = e.dims[2], i = e.dims[3]) : (r = e.dims[3], i = e.dims[2]);
      let a = t?.format !== void 0 ? t.format : "RGB", s = t?.norm, u, f;
      s === void 0 || s.mean === void 0 ? u = [255, 255, 255, 255] : typeof s.mean == "number" ? u = [s.mean, s.mean, s.mean, s.mean] : (u = [s.mean[0], s.mean[1], s.mean[2], 0], s.mean[3] !== void 0 && (u[3] = s.mean[3])), s === void 0 || s.bias === void 0 ? f = [0, 0, 0, 0] : typeof s.bias == "number" ? f = [s.bias, s.bias, s.bias, s.bias] : (f = [s.bias[0], s.bias[1], s.bias[2], 0], s.bias[3] !== void 0 && (f[3] = s.bias[3]));
      let c = i * r, l = 0, d = c, p = c * 2, w = -1;
      a === "RGBA" ? (l = 0, d = c, p = c * 2, w = c * 3) : a === "RGB" ? (l = 0, d = c, p = c * 2) : a === "RBG" && (l = 0, p = c, d = c * 2);
      for (let b = 0; b < i; b++) for (let O = 0; O < r; O++) {
        let m = (e.data[l++] - f[0]) * u[0], h = (e.data[d++] - f[1]) * u[1], P = (e.data[p++] - f[2]) * u[2], g = w === -1 ? 255 : (e.data[w++] - f[3]) * u[3];
        o.fillStyle = "rgba(" + m + "," + h + "," + P + "," + g + ")", o.fillRect(O, b, 1, 1);
      }
      if ("toDataURL" in n) return n.toDataURL();
      throw new Error("toDataURL is not supported");
    } else throw new Error("Can not access image data");
  }, Et = (e, t) => {
    let n = typeof document < "u" ? document.createElement("canvas").getContext("2d") : new OffscreenCanvas(1, 1).getContext("2d"), o;
    if (n != null) {
      let r, i, a;
      t?.tensorLayout !== void 0 && t.tensorLayout === "NHWC" ? (r = e.dims[2], i = e.dims[1], a = e.dims[3]) : (r = e.dims[3], i = e.dims[2], a = e.dims[1]);
      let s = t !== void 0 && t.format !== void 0 ? t.format : "RGB", u = t?.norm, f, c;
      u === void 0 || u.mean === void 0 ? f = [255, 255, 255, 255] : typeof u.mean == "number" ? f = [u.mean, u.mean, u.mean, u.mean] : (f = [u.mean[0], u.mean[1], u.mean[2], 255], u.mean[3] !== void 0 && (f[3] = u.mean[3])), u === void 0 || u.bias === void 0 ? c = [0, 0, 0, 0] : typeof u.bias == "number" ? c = [u.bias, u.bias, u.bias, u.bias] : (c = [u.bias[0], u.bias[1], u.bias[2], 0], u.bias[3] !== void 0 && (c[3] = u.bias[3]));
      let l = i * r;
      if (t !== void 0 && (t.format !== void 0 && a === 4 && t.format !== "RGBA" || a === 3 && t.format !== "RGB" && t.format !== "BGR")) throw new Error("Tensor format doesn't match input tensor dims");
      let d = 4, p = 0, w = 1, b = 2, O = 3, m = 0, h = l, P = l * 2, g = -1;
      s === "RGBA" ? (m = 0, h = l, P = l * 2, g = l * 3) : s === "RGB" ? (m = 0, h = l, P = l * 2) : s === "RBG" && (m = 0, P = l, h = l * 2), o = n.createImageData(r, i);
      for (let S = 0; S < i * r; p += d, w += d, b += d, O += d, S++) o.data[p] = (e.data[m++] - c[0]) * f[0], o.data[w] = (e.data[h++] - c[1]) * f[1], o.data[b] = (e.data[P++] - c[2]) * f[2], o.data[O] = g === -1 ? 255 : (e.data[g++] - c[3]) * f[3];
    } else throw new Error("Can not access image data");
    return o;
  };
});
var Je;
var St;
var At;
var Ot;
var It;
var Pt;
var xt = E(() => {
  "use strict";
  ge();
  Je = (e, t) => {
    if (e === void 0) throw new Error("Image buffer must be defined");
    if (t.height === void 0 || t.width === void 0) throw new Error("Image height and width must be defined");
    if (t.tensorLayout === "NHWC") throw new Error("NHWC Tensor layout is not supported yet");
    let { height: n, width: o } = t, r = t.norm ?? { mean: 255, bias: 0 }, i, a;
    typeof r.mean == "number" ? i = [r.mean, r.mean, r.mean, r.mean] : i = [r.mean[0], r.mean[1], r.mean[2], r.mean[3] ?? 255], typeof r.bias == "number" ? a = [r.bias, r.bias, r.bias, r.bias] : a = [r.bias[0], r.bias[1], r.bias[2], r.bias[3] ?? 0];
    let s = t.format !== void 0 ? t.format : "RGBA", u = t.tensorFormat !== void 0 && t.tensorFormat !== void 0 ? t.tensorFormat : "RGB", f = n * o, c = u === "RGBA" ? new Float32Array(f * 4) : new Float32Array(f * 3), l = 4, d = 0, p = 1, w = 2, b = 3, O = 0, m = f, h = f * 2, P = -1;
    s === "RGB" && (l = 3, d = 0, p = 1, w = 2, b = -1), u === "RGBA" ? P = f * 3 : u === "RBG" ? (O = 0, h = f, m = f * 2) : u === "BGR" && (h = 0, m = f, O = f * 2);
    for (let S = 0; S < f; S++, d += l, w += l, p += l, b += l) c[O++] = (e[d] + a[0]) / i[0], c[m++] = (e[p] + a[1]) / i[1], c[h++] = (e[w] + a[2]) / i[2], P !== -1 && b !== -1 && (c[P++] = (e[b] + a[3]) / i[3]);
    return u === "RGBA" ? new U("float32", c, [1, 4, n, o]) : new U("float32", c, [1, 3, n, o]);
  }, St = async (e, t) => {
    let n = typeof HTMLImageElement < "u" && e instanceof HTMLImageElement, o = typeof ImageData < "u" && e instanceof ImageData, r = typeof ImageBitmap < "u" && e instanceof ImageBitmap, i = typeof e == "string", a, s = t ?? {}, u = () => {
      if (typeof document < "u") return document.createElement("canvas");
      if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(1, 1);
      throw new Error("Canvas is not supported");
    }, f = (c) => typeof HTMLCanvasElement < "u" && c instanceof HTMLCanvasElement || c instanceof OffscreenCanvas ? c.getContext("2d") : null;
    if (n) {
      let c = u();
      c.width = e.width, c.height = e.height;
      let l = f(c);
      if (l != null) {
        let d = e.height, p = e.width;
        if (t !== void 0 && t.resizedHeight !== void 0 && t.resizedWidth !== void 0 && (d = t.resizedHeight, p = t.resizedWidth), t !== void 0) {
          if (s = t, t.tensorFormat !== void 0) throw new Error("Image input config format must be RGBA for HTMLImageElement");
          s.tensorFormat = "RGBA", s.height = d, s.width = p;
        } else s.tensorFormat = "RGBA", s.height = d, s.width = p;
        l.drawImage(e, 0, 0), a = l.getImageData(0, 0, p, d).data;
      } else throw new Error("Can not access image data");
    } else if (o) {
      let c, l;
      if (t !== void 0 && t.resizedWidth !== void 0 && t.resizedHeight !== void 0 ? (c = t.resizedHeight, l = t.resizedWidth) : (c = e.height, l = e.width), t !== void 0 && (s = t), s.format = "RGBA", s.height = c, s.width = l, t !== void 0) {
        let d = u();
        d.width = l, d.height = c;
        let p = f(d);
        if (p != null) p.putImageData(e, 0, 0), a = p.getImageData(0, 0, l, c).data;
        else throw new Error("Can not access image data");
      } else a = e.data;
    } else if (r) {
      if (t === void 0) throw new Error("Please provide image config with format for Imagebitmap");
      let c = u();
      c.width = e.width, c.height = e.height;
      let l = f(c);
      if (l != null) {
        let d = e.height, p = e.width;
        return l.drawImage(e, 0, 0, p, d), a = l.getImageData(0, 0, p, d).data, s.height = d, s.width = p, Je(a, s);
      } else throw new Error("Can not access image data");
    } else {
      if (i) return new Promise((c, l) => {
        let d = u(), p = f(d);
        if (!e || !p) return l();
        let w = new Image();
        w.crossOrigin = "Anonymous", w.src = e, w.onload = () => {
          d.width = w.width, d.height = w.height, p.drawImage(w, 0, 0, d.width, d.height);
          let b = p.getImageData(0, 0, d.width, d.height);
          s.height = d.height, s.width = d.width, c(Je(b.data, s));
        };
      });
      throw new Error("Input data provided is not supported - aborted tensor creation");
    }
    if (a !== void 0) return Je(a, s);
    throw new Error("Input data provided is not supported - aborted tensor creation");
  }, At = (e, t) => {
    let { width: n, height: o, download: r, dispose: i } = t, a = [1, o, n, 4];
    return new U({ location: "texture", type: "float32", texture: e, dims: a, download: r, dispose: i });
  }, Ot = (e, t) => {
    let { dataType: n, dims: o, download: r, dispose: i } = t;
    return new U({ location: "gpu-buffer", type: n ?? "float32", gpuBuffer: e, dims: o, download: r, dispose: i });
  }, It = (e, t) => {
    let { dataType: n, dims: o, download: r, dispose: i } = t;
    return new U({ location: "ml-tensor", type: n ?? "float32", mlTensor: e, dims: o, download: r, dispose: i });
  }, Pt = (e, t, n) => new U({ location: "cpu-pinned", type: e, data: t, dims: n ?? [t.length] });
});
var q;
var de;
var Lt;
var vt;
var Bt = E(() => {
  "use strict";
  q = /* @__PURE__ */ new Map([["float32", Float32Array], ["uint8", Uint8Array], ["int8", Int8Array], ["uint16", Uint16Array], ["int16", Int16Array], ["int32", Int32Array], ["bool", Uint8Array], ["float64", Float64Array], ["uint32", Uint32Array], ["int4", Uint8Array], ["uint4", Uint8Array]]), de = /* @__PURE__ */ new Map([[Float32Array, "float32"], [Uint8Array, "uint8"], [Int8Array, "int8"], [Uint16Array, "uint16"], [Int16Array, "int16"], [Int32Array, "int32"], [Float64Array, "float64"], [Uint32Array, "uint32"]]), Lt = false, vt = () => {
    if (!Lt) {
      Lt = true;
      let e = typeof BigInt64Array < "u" && BigInt64Array.from, t = typeof BigUint64Array < "u" && BigUint64Array.from, n = globalThis.Float16Array, o = typeof n < "u" && n.from;
      e && (q.set("int64", BigInt64Array), de.set(BigInt64Array, "int64")), t && (q.set("uint64", BigUint64Array), de.set(BigUint64Array, "uint64")), o ? (q.set("float16", n), de.set(n, "float16")) : q.set("float16", Uint16Array);
    }
  };
});
var Ut;
var _t;
var Mt = E(() => {
  "use strict";
  ge();
  Ut = (e) => {
    let t = 1;
    for (let n = 0; n < e.length; n++) {
      let o = e[n];
      if (typeof o != "number" || !Number.isSafeInteger(o)) throw new TypeError(`dims[${n}] must be an integer, got: ${o}`);
      if (o < 0) throw new RangeError(`dims[${n}] must be a non-negative integer, got: ${o}`);
      t *= o;
    }
    return t;
  }, _t = (e, t) => {
    switch (e.location) {
      case "cpu":
        return new U(e.type, e.data, t);
      case "cpu-pinned":
        return new U({ location: "cpu-pinned", data: e.data, type: e.type, dims: t });
      case "texture":
        return new U({ location: "texture", texture: e.texture, type: e.type, dims: t });
      case "gpu-buffer":
        return new U({ location: "gpu-buffer", gpuBuffer: e.gpuBuffer, type: e.type, dims: t });
      case "ml-tensor":
        return new U({ location: "ml-tensor", mlTensor: e.mlTensor, type: e.type, dims: t });
      default:
        throw new Error(`tensorReshape: tensor location ${e.location} is not supported`);
    }
  };
});
var U;
var ge = E(() => {
  "use strict";
  Tt();
  xt();
  Bt();
  Mt();
  U = class {
    constructor(t, n, o) {
      vt();
      let r, i;
      if (typeof t == "object" && "location" in t) switch (this.dataLocation = t.location, r = t.type, i = t.dims, t.location) {
        case "cpu-pinned": {
          let s = q.get(r);
          if (!s) throw new TypeError(`unsupported type "${r}" to create tensor from pinned buffer`);
          if (!(t.data instanceof s)) throw new TypeError(`buffer should be of type ${s.name}`);
          this.cpuData = t.data;
          break;
        }
        case "texture": {
          if (r !== "float32") throw new TypeError(`unsupported type "${r}" to create tensor from texture`);
          this.gpuTextureData = t.texture, this.downloader = t.download, this.disposer = t.dispose;
          break;
        }
        case "gpu-buffer": {
          if (r !== "float32" && r !== "float16" && r !== "int32" && r !== "int64" && r !== "uint32" && r !== "uint8" && r !== "bool" && r !== "uint4" && r !== "int4") throw new TypeError(`unsupported type "${r}" to create tensor from gpu buffer`);
          this.gpuBufferData = t.gpuBuffer, this.downloader = t.download, this.disposer = t.dispose;
          break;
        }
        case "ml-tensor": {
          if (r !== "float32" && r !== "float16" && r !== "int32" && r !== "int64" && r !== "uint32" && r !== "uint64" && r !== "int8" && r !== "uint8" && r !== "bool" && r !== "uint4" && r !== "int4") throw new TypeError(`unsupported type "${r}" to create tensor from MLTensor`);
          this.mlTensorData = t.mlTensor, this.downloader = t.download, this.disposer = t.dispose;
          break;
        }
        default:
          throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`);
      }
      else {
        let s, u;
        if (typeof t == "string") if (r = t, u = o, t === "string") {
          if (!Array.isArray(n)) throw new TypeError("A string tensor's data must be a string array.");
          s = n;
        } else {
          let f = q.get(t);
          if (f === void 0) throw new TypeError(`Unsupported tensor type: ${t}.`);
          if (Array.isArray(n)) {
            if (t === "float16" && f === Uint16Array || t === "uint4" || t === "int4") throw new TypeError(`Creating a ${t} tensor from number array is not supported. Please use ${f.name} as data.`);
            t === "uint64" || t === "int64" ? s = f.from(n, BigInt) : s = f.from(n);
          } else if (n instanceof f) s = n;
          else if (n instanceof Uint8ClampedArray) if (t === "uint8") s = Uint8Array.from(n);
          else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");
          else if (t === "float16" && n instanceof Uint16Array && f !== Uint16Array) s = new globalThis.Float16Array(n.buffer, n.byteOffset, n.length);
          else throw new TypeError(`A ${r} tensor's data must be type of ${f}`);
        }
        else if (u = n, Array.isArray(t)) {
          if (t.length === 0) throw new TypeError("Tensor type cannot be inferred from an empty array.");
          let f = typeof t[0];
          if (f === "string") r = "string", s = t;
          else if (f === "boolean") r = "bool", s = Uint8Array.from(t);
          else throw new TypeError(`Invalid element type of data array: ${f}.`);
        } else if (t instanceof Uint8ClampedArray) r = "uint8", s = Uint8Array.from(t);
        else {
          let f = de.get(t.constructor);
          if (f === void 0) throw new TypeError(`Unsupported type for tensor data: ${t.constructor}.`);
          r = f, s = t;
        }
        if (u === void 0) u = [s.length];
        else if (!Array.isArray(u)) throw new TypeError("A tensor's dims must be a number array");
        i = u, this.cpuData = s, this.dataLocation = "cpu";
      }
      let a = Ut(i);
      if (this.cpuData && a !== this.cpuData.length && !((r === "uint4" || r === "int4") && Math.ceil(a / 2) === this.cpuData.length)) throw new Error(`Tensor's size(${a}) does not match data length(${this.cpuData.length}).`);
      this.type = r, this.dims = i, this.size = a;
    }
    static async fromImage(t, n) {
      return St(t, n);
    }
    static fromTexture(t, n) {
      return At(t, n);
    }
    static fromGpuBuffer(t, n) {
      return Ot(t, n);
    }
    static fromMLTensor(t, n) {
      return It(t, n);
    }
    static fromPinnedBuffer(t, n, o) {
      return Pt(t, n, o);
    }
    toDataURL(t) {
      return gt(this, t);
    }
    toImageData(t) {
      return Et(this, t);
    }
    get data() {
      if (this.ensureValid(), !this.cpuData) throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");
      return this.cpuData;
    }
    get location() {
      return this.dataLocation;
    }
    get texture() {
      if (this.ensureValid(), !this.gpuTextureData) throw new Error("The data is not stored as a WebGL texture.");
      return this.gpuTextureData;
    }
    get gpuBuffer() {
      if (this.ensureValid(), !this.gpuBufferData) throw new Error("The data is not stored as a WebGPU buffer.");
      return this.gpuBufferData;
    }
    get mlTensor() {
      if (this.ensureValid(), !this.mlTensorData) throw new Error("The data is not stored as a WebNN MLTensor.");
      return this.mlTensorData;
    }
    async getData(t) {
      switch (this.ensureValid(), this.dataLocation) {
        case "cpu":
        case "cpu-pinned":
          return this.data;
        case "texture":
        case "gpu-buffer":
        case "ml-tensor": {
          if (!this.downloader) throw new Error("The current tensor is not created with a specified data downloader.");
          if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
          try {
            this.isDownloading = true;
            let n = await this.downloader();
            return this.downloader = void 0, this.dataLocation = "cpu", this.cpuData = n, t && this.disposer && (this.disposer(), this.disposer = void 0), n;
          } finally {
            this.isDownloading = false;
          }
        }
        default:
          throw new Error(`cannot get data from location: ${this.dataLocation}`);
      }
    }
    dispose() {
      if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
      this.disposer && (this.disposer(), this.disposer = void 0), this.cpuData = void 0, this.gpuTextureData = void 0, this.gpuBufferData = void 0, this.mlTensorData = void 0, this.downloader = void 0, this.isDownloading = void 0, this.dataLocation = "none";
    }
    ensureValid() {
      if (this.dataLocation === "none") throw new Error("The tensor is disposed.");
    }
    reshape(t) {
      if (this.ensureValid(), this.downloader || this.disposer) throw new Error("Cannot reshape a tensor that owns GPU resource.");
      return _t(this, t);
    }
  };
});
var W;
var Ze = E(() => {
  "use strict";
  ge();
  W = U;
});
var Dt;
var Ct;
var J;
var Z;
var Xe = E(() => {
  "use strict";
  qe();
  Dt = (e, t) => {
    (typeof C.trace > "u" ? !C.wasm.trace : !C.trace) || console.timeStamp(`${e}::ORT::${t}`);
  }, Ct = (e, t) => {
    let n = new Error().stack?.split(/\r\n|\r|\n/g) || [], o = false;
    for (let r = 0; r < n.length; r++) {
      if (o && !n[r].includes("TRACE_FUNC")) {
        let i = `FUNC_${e}::${n[r].trim().split(" ")[1]}`;
        t && (i += `::${t}`), Dt("CPU", i);
        return;
      }
      n[r].includes("TRACE_FUNC") && (o = true);
    }
  }, J = (e) => {
    (typeof C.trace > "u" ? !C.wasm.trace : !C.trace) || Ct("BEGIN", e);
  }, Z = (e) => {
    (typeof C.trace > "u" ? !C.wasm.trace : !C.trace) || Ct("END", e);
  };
});
var Ee;
var Rt = E(() => {
  "use strict";
  Ye();
  Ze();
  Xe();
  Ee = class e {
    constructor(t) {
      this.handler = t;
    }
    async run(t, n, o) {
      J();
      let r = {}, i = {};
      if (typeof t != "object" || t === null || t instanceof W || Array.isArray(t)) throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");
      let a = true;
      if (typeof n == "object") {
        if (n === null) throw new TypeError("Unexpected argument[1]: cannot be null.");
        if (n instanceof W) throw new TypeError("'fetches' cannot be a Tensor");
        if (Array.isArray(n)) {
          if (n.length === 0) throw new TypeError("'fetches' cannot be an empty array.");
          a = false;
          for (let f of n) {
            if (typeof f != "string") throw new TypeError("'fetches' must be a string array or an object.");
            if (this.outputNames.indexOf(f) === -1) throw new RangeError(`'fetches' contains invalid output name: ${f}.`);
            r[f] = null;
          }
          if (typeof o == "object" && o !== null) i = o;
          else if (typeof o < "u") throw new TypeError("'options' must be an object.");
        } else {
          let f = false, c = Object.getOwnPropertyNames(n);
          for (let l of this.outputNames) if (c.indexOf(l) !== -1) {
            let d = n[l];
            (d === null || d instanceof W) && (f = true, a = false, r[l] = d);
          }
          if (f) {
            if (typeof o == "object" && o !== null) i = o;
            else if (typeof o < "u") throw new TypeError("'options' must be an object.");
          } else i = n;
        }
      } else if (typeof n < "u") throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");
      for (let f of this.inputNames) if (typeof t[f] > "u") throw new Error(`input '${f}' is missing in 'feeds'.`);
      if (a) for (let f of this.outputNames) r[f] = null;
      let s = await this.handler.run(t, r, i), u = {};
      for (let f in s) if (Object.hasOwnProperty.call(s, f)) {
        let c = s[f];
        c instanceof W ? u[f] = c : u[f] = new W(c.type, c.data, c.dims);
      }
      return Z(), u;
    }
    async release() {
      return this.handler.dispose();
    }
    static async create(t, n, o, r) {
      J();
      let i, a = {};
      if (typeof t == "string") {
        if (i = t, typeof n == "object" && n !== null) a = n;
        else if (typeof n < "u") throw new TypeError("'options' must be an object.");
      } else if (t instanceof Uint8Array) {
        if (i = t, typeof n == "object" && n !== null) a = n;
        else if (typeof n < "u") throw new TypeError("'options' must be an object.");
      } else if (t instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && t instanceof SharedArrayBuffer) {
        let c = t, l = 0, d = t.byteLength;
        if (typeof n == "object" && n !== null) a = n;
        else if (typeof n == "number") {
          if (l = n, !Number.isSafeInteger(l)) throw new RangeError("'byteOffset' must be an integer.");
          if (l < 0 || l >= c.byteLength) throw new RangeError(`'byteOffset' is out of range [0, ${c.byteLength}).`);
          if (d = t.byteLength - l, typeof o == "number") {
            if (d = o, !Number.isSafeInteger(d)) throw new RangeError("'byteLength' must be an integer.");
            if (d <= 0 || l + d > c.byteLength) throw new RangeError(`'byteLength' is out of range (0, ${c.byteLength - l}].`);
            if (typeof r == "object" && r !== null) a = r;
            else if (typeof r < "u") throw new TypeError("'options' must be an object.");
          } else if (typeof o < "u") throw new TypeError("'byteLength' must be a number.");
        } else if (typeof n < "u") throw new TypeError("'options' must be an object.");
        i = new Uint8Array(c, l, d);
      } else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");
      let [s, u] = await pt(a), f = await s.createInferenceSessionHandler(i, u);
      return Z(), new e(f);
    }
    startProfiling() {
      this.handler.startProfiling();
    }
    endProfiling() {
      this.handler.endProfiling();
    }
    get inputNames() {
      return this.handler.inputNames;
    }
    get outputNames() {
      return this.handler.outputNames;
    }
    get inputMetadata() {
      return this.handler.inputMetadata;
    }
    get outputMetadata() {
      return this.handler.outputMetadata;
    }
  };
});
var Ln;
var Ft = E(() => {
  "use strict";
  Rt();
  Ln = Ee;
});
var kt = E(() => {
  "use strict";
});
var Nt = E(() => {
  "use strict";
});
var Wt = E(() => {
  "use strict";
});
var Gt = E(() => {
  "use strict";
});
var Ke = {};
Ve(Ke, { InferenceSession: () => Ln, TRACE: () => Dt, TRACE_FUNC_BEGIN: () => J, TRACE_FUNC_END: () => Z, Tensor: () => W, env: () => I, registerBackend: () => ce });
var X = E(() => {
  "use strict";
  mt();
  bt();
  Ft();
  Ze();
  kt();
  Nt();
  Xe();
  Wt();
  Gt();
});
var Te = E(() => {
  "use strict";
});
var jt = {};
Ve(jt, { default: () => vn });
var zt;
var Ht;
var vn;
var Vt = E(() => {
  "use strict";
  Qe();
  K();
  Se();
  zt = "ort-wasm-proxy-worker", Ht = globalThis.self?.name === zt;
  Ht && (self.onmessage = (e) => {
    let { type: t, in: n } = e.data;
    try {
      switch (t) {
        case "init-wasm":
          Ae(n.wasm).then(() => {
            Oe(n).then(() => {
              postMessage({ type: t });
            }, (o) => {
              postMessage({ type: t, err: o });
            });
          }, (o) => {
            postMessage({ type: t, err: o });
          });
          break;
        case "init-ep": {
          let { epName: o, env: r } = n;
          Ie(r, o).then(() => {
            postMessage({ type: t });
          }, (i) => {
            postMessage({ type: t, err: i });
          });
          break;
        }
        case "copy-from": {
          let { buffer: o } = n, r = le(o);
          postMessage({ type: t, out: r });
          break;
        }
        case "create": {
          let { model: o, options: r } = n;
          Pe(o, r).then((i) => {
            postMessage({ type: t, out: i });
          }, (i) => {
            postMessage({ type: t, err: i });
          });
          break;
        }
        case "release":
          xe(n), postMessage({ type: t });
          break;
        case "run": {
          let { sessionId: o, inputIndices: r, inputs: i, outputIndices: a, options: s } = n;
          Le(o, r, i, a, new Array(a.length).fill(null), s).then((u) => {
            u.some((f) => f[3] !== "cpu") ? postMessage({ type: t, err: "Proxy does not support non-cpu tensor location." }) : postMessage({ type: t, out: u }, Be([...i, ...u]));
          }, (u) => {
            postMessage({ type: t, err: u });
          });
          break;
        }
        case "end-profiling":
          ve(n), postMessage({ type: t });
          break;
        default:
      }
    } catch (o) {
      postMessage({ type: t, err: o });
    }
  });
  vn = Ht ? null : (e) => new Worker(e ?? R, { type: "module", name: zt });
});
var Jt;
var Bn;
var Un;
var R;
var Ue;
var et;
var _n;
var Mn;
var Zt;
var Dn;
var Yt;
var Xt;
var qt;
var Kt;
var Se = E(() => {
  "use strict";
  Te();
  Jt = typeof location > "u" ? void 0 : location.origin, Bn = import.meta.url > "file:" && import.meta.url < "file;", Un = () => {
    if (true) {
      if (Bn) {
        let e = URL;
        return new URL(new e("ort.wasm.bundle.min.mjs", import.meta.url).href, Jt).href;
      }
      return import.meta.url;
    }
  }, R = Un(), Ue = () => {
    if (R && !R.startsWith("blob:")) return R.substring(0, R.lastIndexOf("/") + 1);
  }, et = (e, t) => {
    try {
      let n = t ?? R;
      return (n ? new URL(e, n) : new URL(e)).origin === Jt;
    } catch {
      return false;
    }
  }, _n = (e, t) => {
    let n = t ?? R;
    try {
      return (n ? new URL(e, n) : new URL(e)).href;
    } catch {
      return;
    }
  }, Mn = (e, t) => `${t ?? "./"}${e}`, Zt = async (e) => {
    let n = await (await fetch(e, { credentials: "same-origin" })).blob();
    return URL.createObjectURL(n);
  }, Dn = async (e) => (await import(
    /*webpackIgnore:true*/
    e
  )).default, Yt = (Vt(), lt(jt)).default, Xt = async () => {
    if (!R) throw new Error("Failed to load proxy worker: cannot determine the script source URL.");
    if (et(R)) return [void 0, Yt()];
    let e = await Zt(R);
    return [e, Yt(e)];
  }, qt = void 0, Kt = async (e, t, n) => {
    if (!e && !t && qt && R && et(R)) return [void 0, qt];
    {
      let o = "ort-wasm-simd-threaded.mjs", r = e ?? _n(o, t), i = n && r && !et(r, t), a = i ? await Zt(r) : r ?? Mn(o, t);
      return [i ? a : void 0, await Dn(a)];
    }
  };
});
var tt;
var nt;
var _e;
var Qt;
var Cn;
var Rn;
var Fn;
var Ae;
var A;
var K = E(() => {
  "use strict";
  Se();
  nt = false, _e = false, Qt = false, Cn = () => {
    if (typeof SharedArrayBuffer > "u") return false;
    try {
      return typeof MessageChannel < "u" && new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)), WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 2, 0, 26, 11]));
    } catch {
      return false;
    }
  }, Rn = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 30, 1, 28, 0, 65, 0, 253, 15, 253, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 253, 186, 1, 26, 11]));
    } catch {
      return false;
    }
  }, Fn = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 19, 1, 17, 0, 65, 1, 253, 15, 65, 2, 253, 15, 65, 3, 253, 15, 253, 147, 2, 11]));
    } catch {
      return false;
    }
  }, Ae = async (e) => {
    if (nt) return Promise.resolve();
    if (_e) throw new Error("multiple calls to 'initializeWebAssembly()' detected.");
    if (Qt) throw new Error("previous call to 'initializeWebAssembly()' failed.");
    _e = true;
    let t = e.initTimeout, n = e.numThreads;
    if (e.simd !== false) {
      if (e.simd === "relaxed") {
        if (!Fn()) throw new Error("Relaxed WebAssembly SIMD is not supported in the current environment.");
      } else if (!Rn()) throw new Error("WebAssembly SIMD is not supported in the current environment.");
    }
    let o = Cn();
    n > 1 && !o && (typeof self < "u" && !self.crossOriginIsolated && console.warn("env.wasm.numThreads is set to " + n + ", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."), console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."), e.numThreads = n = 1);
    let r = e.wasmPaths, i = typeof r == "string" ? r : void 0, a = r?.mjs, s = a?.href ?? a, u = r?.wasm, f = u?.href ?? u, c = e.wasmBinary, [l, d] = await Kt(s, i, n > 1), p = false, w = [];
    if (t > 0 && w.push(new Promise((b) => {
      setTimeout(() => {
        p = true, b();
      }, t);
    })), w.push(new Promise((b, O) => {
      let m = { numThreads: n };
      if (c) m.wasmBinary = c;
      else if (f || i) m.locateFile = (h) => f ?? i + h;
      else if (s && s.indexOf("blob:") !== 0) m.locateFile = (h) => new URL(h, s).href;
      else if (l) {
        let h = Ue();
        h && (m.locateFile = (P) => h + P);
      }
      d(m).then((h) => {
        _e = false, nt = true, tt = h, b(), l && URL.revokeObjectURL(l);
      }, (h) => {
        _e = false, Qt = true, O(h);
      });
    })), await Promise.race(w), p) throw new Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`);
  }, A = () => {
    if (nt && tt) return tt;
    throw new Error("WebAssembly is not initialized yet.");
  };
});
var F;
var pe;
var T;
var Me = E(() => {
  "use strict";
  K();
  F = (e, t) => {
    let n = A(), o = n.lengthBytesUTF8(e) + 1, r = n._malloc(o);
    return n.stringToUTF8(e, r, o), t.push(r), r;
  }, pe = (e, t, n, o) => {
    if (typeof e == "object" && e !== null) {
      if (n.has(e)) throw new Error("Circular reference in options");
      n.add(e);
    }
    Object.entries(e).forEach(([r, i]) => {
      let a = t ? t + r : r;
      if (typeof i == "object") pe(i, a + ".", n, o);
      else if (typeof i == "string" || typeof i == "number") o(a, i.toString());
      else if (typeof i == "boolean") o(a, i ? "1" : "0");
      else throw new Error(`Can't handle extra config type: ${typeof i}`);
    });
  }, T = (e) => {
    let t = A(), n = t.stackSave();
    try {
      let o = t.PTR_SIZE, r = t.stackAlloc(2 * o);
      t._OrtGetLastError(r, r + o);
      let i = Number(t.getValue(r, o === 4 ? "i32" : "i64")), a = t.getValue(r + o, "*"), s = a ? t.UTF8ToString(a) : "";
      throw new Error(`${e} ERROR_CODE: ${i}, ERROR_MESSAGE: ${s}`);
    } finally {
      t.stackRestore(n);
    }
  };
});
var en;
var tn = E(() => {
  "use strict";
  K();
  Me();
  en = (e) => {
    let t = A(), n = 0, o = [], r = e || {};
    try {
      if (e?.logSeverityLevel === void 0) r.logSeverityLevel = 2;
      else if (typeof e.logSeverityLevel != "number" || !Number.isInteger(e.logSeverityLevel) || e.logSeverityLevel < 0 || e.logSeverityLevel > 4) throw new Error(`log serverity level is not valid: ${e.logSeverityLevel}`);
      if (e?.logVerbosityLevel === void 0) r.logVerbosityLevel = 0;
      else if (typeof e.logVerbosityLevel != "number" || !Number.isInteger(e.logVerbosityLevel)) throw new Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);
      e?.terminate === void 0 && (r.terminate = false);
      let i = 0;
      return e?.tag !== void 0 && (i = F(e.tag, o)), n = t._OrtCreateRunOptions(r.logSeverityLevel, r.logVerbosityLevel, !!r.terminate, i), n === 0 && T("Can't create run options."), e?.extra !== void 0 && pe(e.extra, "", /* @__PURE__ */ new WeakSet(), (a, s) => {
        let u = F(a, o), f = F(s, o);
        t._OrtAddRunConfigEntry(n, u, f) !== 0 && T(`Can't set a run config entry: ${a} - ${s}.`);
      }), [n, o];
    } catch (i) {
      throw n !== 0 && t._OrtReleaseRunOptions(n), o.forEach((a) => t._free(a)), i;
    }
  };
});
var kn;
var Nn;
var Wn;
var De;
var Gn;
var nn;
var rn = E(() => {
  "use strict";
  K();
  Me();
  kn = (e) => {
    switch (e) {
      case "disabled":
        return 0;
      case "basic":
        return 1;
      case "extended":
        return 2;
      case "all":
        return 99;
      default:
        throw new Error(`unsupported graph optimization level: ${e}`);
    }
  }, Nn = (e) => {
    switch (e) {
      case "sequential":
        return 0;
      case "parallel":
        return 1;
      default:
        throw new Error(`unsupported execution mode: ${e}`);
    }
  }, Wn = (e) => {
    e.extra || (e.extra = {}), e.extra.session || (e.extra.session = {});
    let t = e.extra.session;
    t.use_ort_model_bytes_directly || (t.use_ort_model_bytes_directly = "1"), e.executionProviders && e.executionProviders.some((n) => (typeof n == "string" ? n : n.name) === "webgpu") && (e.enableMemPattern = false);
  }, De = (e, t, n, o) => {
    let r = F(t, o), i = F(n, o);
    A()._OrtAddSessionConfigEntry(e, r, i) !== 0 && T(`Can't set a session config entry: ${t} - ${n}.`);
  }, Gn = async (e, t, n) => {
    for (let o of t) {
      let r = typeof o == "string" ? o : o.name, i = [];
      switch (r) {
        case "webnn":
          if (r = "WEBNN", typeof o != "string") {
            let l = o?.deviceType;
            l && De(e, "deviceType", l, n);
          }
          break;
        case "webgpu":
          if (r = "JS", typeof o != "string") {
            let c = o;
            if (c?.preferredLayout) {
              if (c.preferredLayout !== "NCHW" && c.preferredLayout !== "NHWC") throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${c.preferredLayout}`);
              De(e, "preferredLayout", c.preferredLayout, n);
            }
          }
          break;
        case "wasm":
        case "cpu":
          continue;
        default:
          throw new Error(`not supported execution provider: ${r}`);
      }
      let a = F(r, n), s = i.length, u = 0, f = 0;
      if (s > 0) {
        u = A()._malloc(s * A().PTR_SIZE), n.push(u), f = A()._malloc(s * A().PTR_SIZE), n.push(f);
        for (let c = 0; c < s; c++) A().setValue(u + c * A().PTR_SIZE, i[c][0], "*"), A().setValue(f + c * A().PTR_SIZE, i[c][1], "*");
      }
      await A()._OrtAppendExecutionProvider(e, a, u, f, s) !== 0 && T(`Can't append execution provider: ${r}.`);
    }
  }, nn = async (e) => {
    let t = A(), n = 0, o = [], r = e || {};
    Wn(r);
    try {
      let i = kn(r.graphOptimizationLevel ?? "all"), a = Nn(r.executionMode ?? "sequential"), s = typeof r.logId == "string" ? F(r.logId, o) : 0, u = r.logSeverityLevel ?? 2;
      if (!Number.isInteger(u) || u < 0 || u > 4) throw new Error(`log serverity level is not valid: ${u}`);
      let f = r.logVerbosityLevel ?? 0;
      if (!Number.isInteger(f) || f < 0 || f > 4) throw new Error(`log verbosity level is not valid: ${f}`);
      let c = typeof r.optimizedModelFilePath == "string" ? F(r.optimizedModelFilePath, o) : 0;
      if (n = t._OrtCreateSessionOptions(i, !!r.enableCpuMemArena, !!r.enableMemPattern, a, !!r.enableProfiling, 0, s, u, f, c), n === 0 && T("Can't create session options."), r.executionProviders && await Gn(n, r.executionProviders, o), r.enableGraphCapture !== void 0) {
        if (typeof r.enableGraphCapture != "boolean") throw new Error(`enableGraphCapture must be a boolean value: ${r.enableGraphCapture}`);
        De(n, "enableGraphCapture", r.enableGraphCapture.toString(), o);
      }
      if (r.freeDimensionOverrides) for (let [l, d] of Object.entries(r.freeDimensionOverrides)) {
        if (typeof l != "string") throw new Error(`free dimension override name must be a string: ${l}`);
        if (typeof d != "number" || !Number.isInteger(d) || d < 0) throw new Error(`free dimension override value must be a non-negative integer: ${d}`);
        let p = F(l, o);
        t._OrtAddFreeDimensionOverride(n, p, d) !== 0 && T(`Can't set a free dimension override: ${l} - ${d}.`);
      }
      return r.extra !== void 0 && pe(r.extra, "", /* @__PURE__ */ new WeakSet(), (l, d) => {
        De(n, l, d, o);
      }), [n, o];
    } catch (i) {
      throw n !== 0 && t._OrtReleaseSessionOptions(n) !== 0 && T("Can't release session options."), o.forEach((a) => t._free(a)), i;
    }
  };
});
var re;
var Ce;
var oe;
var on;
var sn;
var Re;
var Fe;
var an;
var rt = E(() => {
  "use strict";
  re = (e) => {
    switch (e) {
      case "int8":
        return 3;
      case "uint8":
        return 2;
      case "bool":
        return 9;
      case "int16":
        return 5;
      case "uint16":
        return 4;
      case "int32":
        return 6;
      case "uint32":
        return 12;
      case "float16":
        return 10;
      case "float32":
        return 1;
      case "float64":
        return 11;
      case "string":
        return 8;
      case "int64":
        return 7;
      case "uint64":
        return 13;
      case "int4":
        return 22;
      case "uint4":
        return 21;
      default:
        throw new Error(`unsupported data type: ${e}`);
    }
  }, Ce = (e) => {
    switch (e) {
      case 3:
        return "int8";
      case 2:
        return "uint8";
      case 9:
        return "bool";
      case 5:
        return "int16";
      case 4:
        return "uint16";
      case 6:
        return "int32";
      case 12:
        return "uint32";
      case 10:
        return "float16";
      case 1:
        return "float32";
      case 11:
        return "float64";
      case 8:
        return "string";
      case 7:
        return "int64";
      case 13:
        return "uint64";
      case 22:
        return "int4";
      case 21:
        return "uint4";
      default:
        throw new Error(`unsupported data type: ${e}`);
    }
  }, oe = (e, t) => {
    let n = [-1, 4, 1, 1, 2, 2, 4, 8, -1, 1, 2, 8, 4, 8, -1, -1, -1, -1, -1, -1, -1, 0.5, 0.5][e], o = typeof t == "number" ? t : t.reduce((r, i) => r * i, 1);
    return n > 0 ? Math.ceil(o * n) : void 0;
  }, on = (e) => {
    switch (e) {
      case "float16":
        return typeof Float16Array < "u" && Float16Array.from ? Float16Array : Uint16Array;
      case "float32":
        return Float32Array;
      case "uint8":
        return Uint8Array;
      case "int8":
        return Int8Array;
      case "uint16":
        return Uint16Array;
      case "int16":
        return Int16Array;
      case "int32":
        return Int32Array;
      case "bool":
        return Uint8Array;
      case "float64":
        return Float64Array;
      case "uint32":
        return Uint32Array;
      case "int64":
        return BigInt64Array;
      case "uint64":
        return BigUint64Array;
      default:
        throw new Error(`unsupported type: ${e}`);
    }
  }, sn = (e) => {
    switch (e) {
      case "verbose":
        return 0;
      case "info":
        return 1;
      case "warning":
        return 2;
      case "error":
        return 3;
      case "fatal":
        return 4;
      default:
        throw new Error(`unsupported logging level: ${e}`);
    }
  }, Re = (e) => e === "float32" || e === "float16" || e === "int32" || e === "int64" || e === "uint32" || e === "uint8" || e === "bool" || e === "uint4" || e === "int4", Fe = (e) => e === "float32" || e === "float16" || e === "int32" || e === "int64" || e === "uint32" || e === "uint64" || e === "int8" || e === "uint8" || e === "bool" || e === "uint4" || e === "int4", an = (e) => {
    switch (e) {
      case "none":
        return 0;
      case "cpu":
        return 1;
      case "cpu-pinned":
        return 2;
      case "texture":
        return 3;
      case "gpu-buffer":
        return 4;
      case "ml-tensor":
        return 5;
      default:
        throw new Error(`unsupported data location: ${e}`);
    }
  };
});
var me;
var ot = E(() => {
  "use strict";
  Te();
  me = async (e) => {
    if (typeof e == "string") if (false) try {
      let { readFile: t } = je("node:fs/promises");
      return new Uint8Array(await t(e));
    } catch (t) {
      if (t.code === "ERR_FS_FILE_TOO_LARGE") {
        let { createReadStream: n } = je("node:fs"), o = n(e), r = [];
        for await (let i of o) r.push(i);
        return new Uint8Array(Buffer.concat(r));
      }
      throw t;
    }
    else {
      let t = await fetch(e);
      if (!t.ok) throw new Error(`failed to load external data file: ${e}`);
      let n = t.headers.get("Content-Length"), o = n ? parseInt(n, 10) : 0;
      if (o < 1073741824) return new Uint8Array(await t.arrayBuffer());
      {
        if (!t.body) throw new Error(`failed to load external data file: ${e}, no response body.`);
        let r = t.body.getReader(), i;
        try {
          i = new ArrayBuffer(o);
        } catch (s) {
          if (s instanceof RangeError) {
            let u = Math.ceil(o / 65536);
            i = new WebAssembly.Memory({ initial: u, maximum: u }).buffer;
          } else throw s;
        }
        let a = 0;
        for (; ; ) {
          let { done: s, value: u } = await r.read();
          if (s) break;
          let f = u.byteLength;
          new Uint8Array(i, a, f).set(u), a += f;
        }
        return new Uint8Array(i, 0, o);
      }
    }
    else return e instanceof Blob ? new Uint8Array(await e.arrayBuffer()) : e instanceof Uint8Array ? e : new Uint8Array(e);
  };
});
var $n;
var Oe;
var Ie;
var se;
var zn;
var un;
var le;
var Pe;
var xe;
var fn;
var Le;
var ve;
var Be;
var Qe = E(() => {
  "use strict";
  tn();
  rn();
  rt();
  K();
  Me();
  ot();
  $n = (e, t) => {
    A()._OrtInit(e, t) !== 0 && T("Can't initialize onnxruntime.");
  }, Oe = async (e) => {
    $n(e.wasm.numThreads, sn(e.logLevel));
  }, Ie = async (e, t) => {
    A().asyncInit?.();
  }, se = /* @__PURE__ */ new Map(), zn = (e) => {
    let t = A(), n = t.stackSave();
    try {
      let o = t.PTR_SIZE, r = t.stackAlloc(2 * o);
      t._OrtGetInputOutputCount(e, r, r + o) !== 0 && T("Can't get session input/output count.");
      let a = o === 4 ? "i32" : "i64";
      return [Number(t.getValue(r, a)), Number(t.getValue(r + o, a))];
    } finally {
      t.stackRestore(n);
    }
  }, un = (e, t) => {
    let n = A(), o = n.stackSave(), r = 0;
    try {
      let i = n.PTR_SIZE, a = n.stackAlloc(2 * i);
      n._OrtGetInputOutputMetadata(e, t, a, a + i) !== 0 && T("Can't get session input/output metadata.");
      let u = Number(n.getValue(a, "*"));
      r = Number(n.getValue(a + i, "*"));
      let f = n.HEAP32[r / 4];
      if (f === 0) return [u, 0];
      let c = n.HEAPU32[r / 4 + 1], l = [];
      for (let d = 0; d < c; d++) {
        let p = Number(n.getValue(r + 8 + d * i, "*"));
        l.push(p !== 0 ? n.UTF8ToString(p) : Number(n.getValue(r + 8 + (d + c) * i, "*")));
      }
      return [u, f, l];
    } finally {
      n.stackRestore(o), r !== 0 && n._OrtFree(r);
    }
  }, le = (e) => {
    let t = A(), n = t._malloc(e.byteLength);
    if (n === 0) throw new Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);
    return t.HEAPU8.set(e, n), [n, e.byteLength];
  }, Pe = async (e, t) => {
    let n, o, r = A();
    Array.isArray(e) ? [n, o] = e : e.buffer === r.HEAPU8.buffer ? [n, o] = [e.byteOffset, e.byteLength] : [n, o] = le(e);
    let i = 0, a = 0, s = 0, u = [], f = [], c = [];
    try {
      if ([a, u] = await nn(t), t?.externalData && r.mountExternalData) {
        let g = [];
        for (let S of t.externalData) {
          let B = typeof S == "string" ? S : S.path;
          g.push(me(typeof S == "string" ? S : S.data).then((D) => {
            r.mountExternalData(B, D);
          }));
        }
        await Promise.all(g);
      }
      for (let g of t?.executionProviders ?? []) if ((typeof g == "string" ? g : g.name) === "webnn") {
        if (r.shouldTransferToMLTensor = false, typeof g != "string") {
          let B = g, D = B?.context, _ = B?.gpuDevice, te = B?.deviceType, ue = B?.powerPreference;
          D ? r.currentContext = D : _ ? r.currentContext = await r.webnnCreateMLContext(_) : r.currentContext = await r.webnnCreateMLContext({ deviceType: te, powerPreference: ue });
        } else r.currentContext = await r.webnnCreateMLContext();
        break;
      }
      i = await r._OrtCreateSession(n, o, a), r.webgpuOnCreateSession?.(i), i === 0 && T("Can't create a session."), r.jsepOnCreateSession?.(), r.currentContext && (r.webnnRegisterMLContext(i, r.currentContext), r.currentContext = void 0, r.shouldTransferToMLTensor = true);
      let [l, d] = zn(i), p = !!t?.enableGraphCapture, w = [], b = [], O = [], m = [], h = [];
      for (let g = 0; g < l; g++) {
        let [S, B, D] = un(i, g);
        S === 0 && T("Can't get an input name."), f.push(S);
        let _ = r.UTF8ToString(S);
        w.push(_), O.push(B === 0 ? { name: _, isTensor: false } : { name: _, isTensor: true, type: Ce(B), shape: D });
      }
      for (let g = 0; g < d; g++) {
        let [S, B, D] = un(i, g + l);
        S === 0 && T("Can't get an output name."), c.push(S);
        let _ = r.UTF8ToString(S);
        b.push(_), m.push(B === 0 ? { name: _, isTensor: false } : { name: _, isTensor: true, type: Ce(B), shape: D });
      }
      return se.set(i, [i, f, c, null, p, false]), [i, w, b, O, m];
    } catch (l) {
      throw f.forEach((d) => r._OrtFree(d)), c.forEach((d) => r._OrtFree(d)), s !== 0 && r._OrtReleaseBinding(s) !== 0 && T("Can't release IO binding."), i !== 0 && r._OrtReleaseSession(i) !== 0 && T("Can't release session."), l;
    } finally {
      r._free(n), a !== 0 && r._OrtReleaseSessionOptions(a) !== 0 && T("Can't release session options."), u.forEach((l) => r._free(l)), r.unmountExternalData?.();
    }
  }, xe = (e) => {
    let t = A(), n = se.get(e);
    if (!n) throw new Error(`cannot release session. invalid session id: ${e}`);
    let [o, r, i, a, s] = n;
    a && (s && t._OrtClearBoundOutputs(a.handle) !== 0 && T("Can't clear bound outputs."), t._OrtReleaseBinding(a.handle) !== 0 && T("Can't release IO binding.")), t.jsepOnReleaseSession?.(e), t.webnnOnReleaseSession?.(e), t.webgpuOnReleaseSession?.(e), r.forEach((u) => t._OrtFree(u)), i.forEach((u) => t._OrtFree(u)), t._OrtReleaseSession(o) !== 0 && T("Can't release session."), se.delete(e);
  }, fn = async (e, t, n, o, r, i, a = false) => {
    if (!e) {
      t.push(0);
      return;
    }
    let s = A(), u = s.PTR_SIZE, f = e[0], c = e[1], l = e[3], d = l, p, w;
    if (f === "string" && (l === "gpu-buffer" || l === "ml-tensor")) throw new Error("String tensor is not supported on GPU.");
    if (a && l !== "gpu-buffer") throw new Error(`External buffer must be provided for input/output index ${i} when enableGraphCapture is true.`);
    if (l === "gpu-buffer") {
      let m = e[2].gpuBuffer;
      w = oe(re(f), c);
      {
        let h = s.jsepRegisterBuffer;
        if (!h) throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');
        p = h(o, i, m, w);
      }
    } else if (l === "ml-tensor") {
      let m = e[2].mlTensor;
      w = oe(re(f), c);
      let h = s.webnnRegisterMLTensor;
      if (!h) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
      p = h(o, m, re(f), c);
    } else {
      let m = e[2];
      if (Array.isArray(m)) {
        w = u * m.length, p = s._malloc(w), n.push(p);
        for (let h = 0; h < m.length; h++) {
          if (typeof m[h] != "string") throw new TypeError(`tensor data at index ${h} is not a string`);
          s.setValue(p + h * u, F(m[h], n), "*");
        }
      } else {
        let h = s.webnnIsGraphInput, P = s.webnnIsGraphOutput;
        if (f !== "string" && h && P) {
          let g = s.UTF8ToString(r);
          if (h(o, g) || P(o, g)) {
            let S = re(f);
            w = oe(S, c), d = "ml-tensor";
            let B = s.webnnCreateTemporaryTensor, D = s.webnnUploadTensor;
            if (!B || !D) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
            let _ = await B(o, S, c);
            D(_, new Uint8Array(m.buffer, m.byteOffset, m.byteLength)), p = _;
          } else w = m.byteLength, p = s._malloc(w), n.push(p), s.HEAPU8.set(new Uint8Array(m.buffer, m.byteOffset, w), p);
        } else w = m.byteLength, p = s._malloc(w), n.push(p), s.HEAPU8.set(new Uint8Array(m.buffer, m.byteOffset, w), p);
      }
    }
    let b = s.stackSave(), O = s.stackAlloc(4 * c.length);
    try {
      c.forEach((h, P) => s.setValue(O + P * u, h, u === 4 ? "i32" : "i64"));
      let m = s._OrtCreateTensor(re(f), p, w, O, c.length, an(d));
      m === 0 && T(`Can't create tensor for input/output. session=${o}, index=${i}.`), t.push(m);
    } finally {
      s.stackRestore(b);
    }
  }, Le = async (e, t, n, o, r, i) => {
    let a = A(), s = a.PTR_SIZE, u = se.get(e);
    if (!u) throw new Error(`cannot run inference. invalid session id: ${e}`);
    let f = u[0], c = u[1], l = u[2], d = u[3], p = u[4], w = u[5], b = t.length, O = o.length, m = 0, h = [], P = [], g = [], S = [], B = a.stackSave(), D = a.stackAlloc(b * s), _ = a.stackAlloc(b * s), te = a.stackAlloc(O * s), ue = a.stackAlloc(O * s);
    try {
      [m, h] = en(i);
      for (let y = 0; y < b; y++) await fn(n[y], P, S, e, c[t[y]], t[y], p);
      for (let y = 0; y < O; y++) await fn(r[y], g, S, e, l[o[y]], b + o[y], p);
      for (let y = 0; y < b; y++) a.setValue(D + y * s, P[y], "*"), a.setValue(_ + y * s, c[t[y]], "*");
      for (let y = 0; y < O; y++) a.setValue(te + y * s, g[y], "*"), a.setValue(ue + y * s, l[o[y]], "*");
      a.jsepOnRunStart?.(f), a.webnnOnRunStart?.(f);
      let k;
      k = await a._OrtRun(f, _, D, b, ue, O, te, m), k !== 0 && T("failed to call OrtRun().");
      let $ = [], ut = [];
      for (let y = 0; y < O; y++) {
        let z = Number(a.getValue(te + y * s, "*"));
        if (z === g[y]) {
          $.push(r[y]);
          continue;
        }
        let ft = a.stackSave(), G = a.stackAlloc(4 * s), ne = false, L, M = 0;
        try {
          a._OrtGetTensorData(z, G, G + s, G + 2 * s, G + 3 * s) !== 0 && T(`Can't access output tensor data on index ${y}.`);
          let ze = s === 4 ? "i32" : "i64", he = Number(a.getValue(G, ze));
          M = a.getValue(G + s, "*");
          let ct = a.getValue(G + s * 2, "*"), Sn = Number(a.getValue(G + s * 3, ze)), H = [];
          for (let v = 0; v < Sn; v++) H.push(Number(a.getValue(ct + v * s, ze)));
          a._OrtFree(ct) !== 0 && T("Can't free memory for tensor dims.");
          let j = H.reduce((v, x) => v * x, 1);
          L = Ce(he);
          let fe = d?.outputPreferredLocations[o[y]];
          if (L === "string") {
            if (fe === "gpu-buffer" || fe === "ml-tensor") throw new Error("String tensor is not supported on GPU.");
            let v = [];
            for (let x = 0; x < j; x++) {
              let V = a.getValue(M + x * s, "*"), ye = a.getValue(M + (x + 1) * s, "*"), dt = x === j - 1 ? void 0 : ye - V;
              v.push(a.UTF8ToString(V, dt));
            }
            $.push([L, H, v, "cpu"]);
          } else if (fe === "gpu-buffer" && j > 0) {
            let v = a.jsepGetBuffer;
            if (!v) throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');
            let x = v(M), V = oe(he, j);
            if (V === void 0 || !Re(L)) throw new Error(`Unsupported data type: ${L}`);
            ne = true, $.push([L, H, { gpuBuffer: x, download: a.jsepCreateDownloader(x, V, L), dispose: () => {
              a._OrtReleaseTensor(z) !== 0 && T("Can't release tensor.");
            } }, "gpu-buffer"]);
          } else if (fe === "ml-tensor" && j > 0) {
            let v = a.webnnEnsureTensor, x = a.webnnIsGraphInputOutputTypeSupported;
            if (!v || !x) throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');
            if (oe(he, j) === void 0 || !Fe(L)) throw new Error(`Unsupported data type: ${L}`);
            if (!x(e, L, false)) throw new Error(`preferredLocation "ml-tensor" for ${L} output is not supported by current WebNN Context.`);
            let ye = await v(e, M, he, H, false);
            ne = true, $.push([L, H, { mlTensor: ye, download: a.webnnCreateMLTensorDownloader(M, L), dispose: () => {
              a.webnnReleaseTensorId(M), a._OrtReleaseTensor(z);
            } }, "ml-tensor"]);
          } else if (fe === "ml-tensor-cpu-output" && j > 0) {
            let v = a.webnnCreateMLTensorDownloader(M, L)(), x = $.length;
            ne = true, ut.push((async () => {
              let V = [x, await v];
              return a.webnnReleaseTensorId(M), a._OrtReleaseTensor(z), V;
            })()), $.push([L, H, [], "cpu"]);
          } else {
            let v = on(L), x = new v(j);
            new Uint8Array(x.buffer, x.byteOffset, x.byteLength).set(a.HEAPU8.subarray(M, M + x.byteLength)), $.push([L, H, x, "cpu"]);
          }
        } finally {
          a.stackRestore(ft), L === "string" && M && a._free(M), ne || a._OrtReleaseTensor(z);
        }
      }
      d && !p && (a._OrtClearBoundOutputs(d.handle) !== 0 && T("Can't clear bound outputs."), se.set(e, [f, c, l, d, p, false]));
      for (let [y, z] of await Promise.all(ut)) $[y][2] = z;
      return $;
    } finally {
      a.webnnOnRunEnd?.(f), a.stackRestore(B), P.forEach((k) => a._OrtReleaseTensor(k)), g.forEach((k) => a._OrtReleaseTensor(k)), S.forEach((k) => a._free(k)), m !== 0 && a._OrtReleaseRunOptions(m), h.forEach((k) => a._free(k));
    }
  }, ve = (e) => {
    let t = A(), n = se.get(e);
    if (!n) throw new Error("invalid session id");
    let o = n[0], r = t._OrtEndProfiling(o);
    r === 0 && T("Can't get an profile file name."), t._OrtFree(r);
  }, Be = (e) => {
    let t = [];
    for (let n of e) {
      let o = n[2];
      !Array.isArray(o) && "buffer" in o && t.push(o.buffer);
    }
    return t;
  };
});
var ee;
var N;
var we;
var Ne;
var We;
var ke;
var st;
var at;
var ae;
var ie;
var jn;
var cn;
var dn;
var ln;
var pn;
var mn;
var wn;
var hn;
var it = E(() => {
  "use strict";
  X();
  Qe();
  K();
  Se();
  ee = () => !!I.wasm.proxy && typeof document < "u", we = false, Ne = false, We = false, at = /* @__PURE__ */ new Map(), ae = (e, t) => {
    let n = at.get(e);
    n ? n.push(t) : at.set(e, [t]);
  }, ie = () => {
    if (we || !Ne || We || !N) throw new Error("worker not ready");
  }, jn = (e) => {
    switch (e.data.type) {
      case "init-wasm":
        we = false, e.data.err ? (We = true, st[1](e.data.err)) : (Ne = true, st[0]()), ke && (URL.revokeObjectURL(ke), ke = void 0);
        break;
      case "init-ep":
      case "copy-from":
      case "create":
      case "release":
      case "run":
      case "end-profiling": {
        let t = at.get(e.data.type);
        e.data.err ? t.shift()[1](e.data.err) : t.shift()[0](e.data.out);
        break;
      }
      default:
    }
  }, cn = async () => {
    if (!Ne) {
      if (we) throw new Error("multiple calls to 'initWasm()' detected.");
      if (We) throw new Error("previous call to 'initWasm()' failed.");
      if (we = true, ee()) return new Promise((e, t) => {
        N?.terminate(), Xt().then(([n, o]) => {
          try {
            N = o, N.onerror = (i) => t(i), N.onmessage = jn, st = [e, t];
            let r = { type: "init-wasm", in: I };
            if (!r.in.wasm.wasmPaths && n) {
              let i = Ue();
              i && (r.in.wasm.wasmPaths = i);
            }
            N.postMessage(r), ke = n;
          } catch (r) {
            t(r);
          }
        }, t);
      });
      try {
        await Ae(I.wasm), await Oe(I), Ne = true;
      } catch (e) {
        throw We = true, e;
      } finally {
        we = false;
      }
    }
  }, dn = async (e) => {
    if (ee()) return ie(), new Promise((t, n) => {
      ae("init-ep", [t, n]);
      let o = { type: "init-ep", in: { epName: e, env: I } };
      N.postMessage(o);
    });
    await Ie(I, e);
  }, ln = async (e) => ee() ? (ie(), new Promise((t, n) => {
    ae("copy-from", [t, n]);
    let o = { type: "copy-from", in: { buffer: e } };
    N.postMessage(o, [e.buffer]);
  })) : le(e), pn = async (e, t) => {
    if (ee()) {
      if (t?.preferredOutputLocation) throw new Error('session option "preferredOutputLocation" is not supported for proxy.');
      return ie(), new Promise((n, o) => {
        ae("create", [n, o]);
        let r = { type: "create", in: { model: e, options: { ...t } } }, i = [];
        e instanceof Uint8Array && i.push(e.buffer), N.postMessage(r, i);
      });
    } else return Pe(e, t);
  }, mn = async (e) => {
    if (ee()) return ie(), new Promise((t, n) => {
      ae("release", [t, n]);
      let o = { type: "release", in: e };
      N.postMessage(o);
    });
    xe(e);
  }, wn = async (e, t, n, o, r, i) => {
    if (ee()) {
      if (n.some((a) => a[3] !== "cpu")) throw new Error("input tensor on GPU is not supported for proxy.");
      if (r.some((a) => a)) throw new Error("pre-allocated output tensor is not supported for proxy.");
      return ie(), new Promise((a, s) => {
        ae("run", [a, s]);
        let u = n, f = { type: "run", in: { sessionId: e, inputIndices: t, inputs: u, outputIndices: o, options: i } };
        N.postMessage(f, Be(u));
      });
    } else return Le(e, t, n, o, r, i);
  }, hn = async (e) => {
    if (ee()) return ie(), new Promise((t, n) => {
      ae("end-profiling", [t, n]);
      let o = { type: "end-profiling", in: e };
      N.postMessage(o);
    });
    ve(e);
  };
});
var yn;
var Vn;
var Ge;
var bn = E(() => {
  "use strict";
  X();
  it();
  rt();
  Te();
  ot();
  yn = (e, t) => {
    switch (e.location) {
      case "cpu":
        return [e.type, e.dims, e.data, "cpu"];
      case "gpu-buffer":
        return [e.type, e.dims, { gpuBuffer: e.gpuBuffer }, "gpu-buffer"];
      case "ml-tensor":
        return [e.type, e.dims, { mlTensor: e.mlTensor }, "ml-tensor"];
      default:
        throw new Error(`invalid data location: ${e.location} for ${t()}`);
    }
  }, Vn = (e) => {
    switch (e[3]) {
      case "cpu":
        return new W(e[0], e[2], e[1]);
      case "gpu-buffer": {
        let t = e[0];
        if (!Re(t)) throw new Error(`not supported data type: ${t} for deserializing GPU tensor`);
        let { gpuBuffer: n, download: o, dispose: r } = e[2];
        return W.fromGpuBuffer(n, { dataType: t, dims: e[1], download: o, dispose: r });
      }
      case "ml-tensor": {
        let t = e[0];
        if (!Fe(t)) throw new Error(`not supported data type: ${t} for deserializing MLTensor tensor`);
        let { mlTensor: n, download: o, dispose: r } = e[2];
        return W.fromMLTensor(n, { dataType: t, dims: e[1], download: o, dispose: r });
      }
      default:
        throw new Error(`invalid data location: ${e[3]}`);
    }
  }, Ge = class {
    async fetchModelAndCopyToWasmMemory(t) {
      return ln(await me(t));
    }
    async loadModel(t, n) {
      J();
      let o;
      typeof t == "string" ? o = await this.fetchModelAndCopyToWasmMemory(t) : o = t, [this.sessionId, this.inputNames, this.outputNames, this.inputMetadata, this.outputMetadata] = await pn(o, n), Z();
    }
    async dispose() {
      return mn(this.sessionId);
    }
    async run(t, n, o) {
      J();
      let r = [], i = [];
      Object.entries(t).forEach((d) => {
        let p = d[0], w = d[1], b = this.inputNames.indexOf(p);
        if (b === -1) throw new Error(`invalid input '${p}'`);
        r.push(w), i.push(b);
      });
      let a = [], s = [];
      Object.entries(n).forEach((d) => {
        let p = d[0], w = d[1], b = this.outputNames.indexOf(p);
        if (b === -1) throw new Error(`invalid output '${p}'`);
        a.push(w), s.push(b);
      });
      let u = r.map((d, p) => yn(d, () => `input "${this.inputNames[i[p]]}"`)), f = a.map((d, p) => d ? yn(d, () => `output "${this.outputNames[s[p]]}"`) : null), c = await wn(this.sessionId, i, u, s, f, o), l = {};
      for (let d = 0; d < c.length; d++) l[this.outputNames[s[d]]] = a[d] ?? Vn(c[d]);
      return Z(), l;
    }
    startProfiling() {
    }
    endProfiling() {
      hn(this.sessionId);
    }
  };
});
var En = {};
Ve(En, { OnnxruntimeWebAssemblyBackend: () => $e, initializeFlags: () => gn, wasmBackend: () => Yn });
var gn;
var $e;
var Yn;
var Tn = E(() => {
  "use strict";
  X();
  it();
  bn();
  gn = () => {
    (typeof I.wasm.initTimeout != "number" || I.wasm.initTimeout < 0) && (I.wasm.initTimeout = 0);
    let e = I.wasm.simd;
    if (typeof e != "boolean" && e !== void 0 && e !== "fixed" && e !== "relaxed" && (console.warn(`Property "env.wasm.simd" is set to unknown value "${e}". Reset it to \`false\` and ignore SIMD feature checking.`), I.wasm.simd = false), typeof I.wasm.proxy != "boolean" && (I.wasm.proxy = false), typeof I.wasm.trace != "boolean" && (I.wasm.trace = false), typeof I.wasm.numThreads != "number" || !Number.isInteger(I.wasm.numThreads) || I.wasm.numThreads <= 0) if (typeof self < "u" && !self.crossOriginIsolated) I.wasm.numThreads = 1;
    else {
      let t = typeof navigator > "u" ? je("node:os").cpus().length : navigator.hardwareConcurrency;
      I.wasm.numThreads = Math.min(4, Math.ceil((t || 1) / 2));
    }
  }, $e = class {
    async init(t) {
      gn(), await cn(), await dn(t);
    }
    async createInferenceSessionHandler(t, n) {
      let o = new Ge();
      return await o.loadModel(t, n), o;
    }
  }, Yn = new $e();
});
X();
X();
X();
var $t = "1.22.0";
var vo = Ke;
{
  let e = (Tn(), lt(En)).wasmBackend;
  ce("cpu", e, 10), ce("wasm", e, 10);
}
Object.defineProperty(I.versions, "web", { value: $t, enumerable: true });

// src/audio/fbank.ts
var SR = 16e3;
var FRAME_LEN = 400;
var FRAME_SHIFT = 160;
var NUM_MEL = 80;
var FFT_N = 512;
var PREEMPH = 0.97;
var FLT_EPS = 11920928955078125e-23;
var mel = (f) => 1127 * Math.log(1 + f / 700);
function buildWindow() {
  const w = new Float64Array(FRAME_LEN);
  const a = 2 * Math.PI / (FRAME_LEN - 1);
  for (let i = 0; i < FRAME_LEN; i++) w[i] = 0.54 - 0.46 * Math.cos(a * i);
  return w;
}
function buildMelBanks() {
  const numFftBins = FFT_N / 2;
  const binWidth = SR / FFT_N;
  const lo = mel(20), hi = mel(SR / 2);
  const delta = (hi - lo) / (NUM_MEL + 1);
  const banks = [];
  for (let b = 0; b < NUM_MEL; b++) {
    const left = lo + b * delta, center = left + delta, right = center + delta;
    const tmp = new Float64Array(numFftBins);
    let first = -1, last = -1;
    for (let i = 0; i < numFftBins; i++) {
      const m = mel(binWidth * i);
      if (m > left && m < right) {
        tmp[i] = m <= center ? (m - left) / (center - left) : (right - m) / (right - center);
        if (first < 0) first = i;
        last = i;
      }
    }
    banks.push({ start: first, weights: tmp.slice(first, last + 1) });
  }
  return banks;
}
var WINDOW = buildWindow();
var BANKS = buildMelBanks();
var REV = (() => {
  const r = new Uint16Array(FFT_N);
  const bits = Math.log2(FFT_N);
  for (let i = 0; i < FFT_N; i++) {
    let x = i, y = 0;
    for (let b = 0; b < bits; b++) {
      y = y << 1 | x & 1;
      x >>= 1;
    }
    r[i] = y;
  }
  return r;
})();
var COS = new Float64Array(FFT_N / 2);
var SIN = new Float64Array(FFT_N / 2);
for (let i = 0; i < FFT_N / 2; i++) {
  COS[i] = Math.cos(2 * Math.PI * i / FFT_N);
  SIN[i] = -Math.sin(2 * Math.PI * i / FFT_N);
}
function fft(re2, im) {
  for (let i = 0; i < FFT_N; i++) {
    const j = REV[i];
    if (j > i) {
      let t = re2[i];
      re2[i] = re2[j];
      re2[j] = t;
      t = im[i];
      im[i] = im[j];
      im[j] = t;
    }
  }
  for (let size = 2; size <= FFT_N; size <<= 1) {
    const half = size >> 1, step = FFT_N / size;
    for (let s = 0; s < FFT_N; s += size) {
      for (let k = 0; k < half; k++) {
        const wr = COS[k * step], wi = SIN[k * step];
        const a = s + k, b = a + half;
        const tr = re2[b] * wr - im[b] * wi, ti = re2[b] * wi + im[b] * wr;
        re2[b] = re2[a] - tr;
        im[b] = im[a] - ti;
        re2[a] += tr;
        im[a] += ti;
      }
    }
  }
}
function numFrames(numSamples) {
  return numSamples < FRAME_LEN ? 0 : 1 + Math.floor((numSamples - FRAME_LEN) / FRAME_SHIFT);
}
function fbank(samples) {
  const n = numFrames(samples.length);
  const out = new Float32Array(n * NUM_MEL);
  const frame = new Float64Array(FRAME_LEN);
  const re2 = new Float64Array(FFT_N), im = new Float64Array(FFT_N);
  const power = new Float64Array(FFT_N / 2 + 1);
  for (let f = 0; f < n; f++) {
    const off = f * FRAME_SHIFT;
    let mean = 0;
    for (let i = 0; i < FRAME_LEN; i++) {
      frame[i] = samples[off + i] * 32768;
      mean += frame[i];
    }
    mean /= FRAME_LEN;
    for (let i = 0; i < FRAME_LEN; i++) frame[i] -= mean;
    for (let i = FRAME_LEN - 1; i > 0; i--) frame[i] -= PREEMPH * frame[i - 1];
    frame[0] -= PREEMPH * frame[0];
    re2.fill(0);
    im.fill(0);
    for (let i = 0; i < FRAME_LEN; i++) re2[i] = frame[i] * WINDOW[i];
    fft(re2, im);
    for (let i = 0; i <= FFT_N / 2; i++) power[i] = re2[i] * re2[i] + im[i] * im[i];
    for (let b = 0; b < NUM_MEL; b++) {
      const { start: start2, weights } = BANKS[b];
      let e = 0;
      for (let k = 0; k < weights.length; k++) e += weights[k] * power[start2 + k];
      out[f * NUM_MEL + b] = Math.log(Math.max(e, FLT_EPS));
    }
  }
  return out;
}
function cmn(feats, frames) {
  const mean = new Float64Array(NUM_MEL);
  for (let f = 0; f < frames; f++) for (let b = 0; b < NUM_MEL; b++) mean[b] += feats[f * NUM_MEL + b];
  for (let b = 0; b < NUM_MEL; b++) mean[b] /= frames;
  for (let f = 0; f < frames; f++) for (let b = 0; b < NUM_MEL; b++) feats[f * NUM_MEL + b] -= mean[b];
  return feats;
}

// src/audio/embed.ts
var WINDOW_SAMPLES = 24e3;
var WINDOW_FRAMES = numFrames(WINDOW_SAMPLES);
var Embedder = class _Embedder {
  constructor(ort, sess) {
    this.ort = ort;
    this.sess = sess;
  }
  ort;
  sess;
  static async create(ort, model) {
    const sess = await ort.InferenceSession.create(model instanceof Uint8Array ? model : new Uint8Array(model), {
      executionProviders: ["wasm"]
    });
    return new _Embedder(ort, sess);
  }
  /** Embed features already computed (frames x 80, CMN applied). Returns L2-normalized vector. */
  async embedFeats(feats, frames) {
    const t = new this.ort.Tensor("float32", feats, [1, frames, NUM_MEL]);
    const out = await this.sess.run({ feats: t });
    const e = out["embs"].data;
    let n = 0;
    for (let i = 0; i < e.length; i++) n += e[i] * e[i];
    n = Math.sqrt(n);
    const r = new Float32Array(e.length);
    for (let i = 0; i < e.length; i++) r[i] = e[i] / n;
    return r;
  }
  /** Full path from 16 kHz samples (1.5 s window) to embedding. */
  async embed(samples) {
    const frames = numFrames(samples.length);
    return this.embedFeats(cmn(fbank(samples), frames), frames);
  }
};
function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

// src/audio/vad.ts
var VAD_CHUNK = 512;
var CONTEXT = 64;
var SileroVAD = class _SileroVAD {
  constructor(ort, sess) {
    this.ort = ort;
    this.sess = sess;
    this.sr = new ort.Tensor("int64", BigInt64Array.from([16000n]), []);
  }
  ort;
  sess;
  state = new Float32Array(2 * 128);
  context = new Float32Array(CONTEXT);
  sr;
  static async create(ort, model) {
    const sess = await ort.InferenceSession.create(model instanceof Uint8Array ? model : new Uint8Array(model), {
      executionProviders: ["wasm"]
    });
    return new _SileroVAD(ort, sess);
  }
  reset() {
    this.state = new Float32Array(2 * 128);
    this.context = new Float32Array(CONTEXT);
  }
  async prob(chunk) {
    const x = new Float32Array(CONTEXT + VAD_CHUNK);
    x.set(this.context, 0);
    x.set(chunk, CONTEXT);
    const out = await this.sess.run({
      input: new this.ort.Tensor("float32", x, [1, CONTEXT + VAD_CHUNK]),
      state: new this.ort.Tensor("float32", this.state, [2, 1, 128]),
      sr: this.sr
    });
    this.state = new Float32Array(out["stateN"].data);
    this.context = x.slice(x.length - CONTEXT);
    return out["output"].data[0];
  }
};

// src/audio/analyzer.ts
var HOP_SAMPLES = 8e3;
var VAD_THRESHOLD = 0.5;
var MIN_SPEECH_RATIO = 0.6;
var VAD_PER_WINDOW = Math.floor(WINDOW_SAMPLES / VAD_CHUNK);
var Analyzer = class {
  constructor(vad, emb, voiceprints) {
    this.vad = vad;
    this.emb = emb;
    this.voiceprints = voiceprints;
  }
  vad;
  emb;
  voiceprints;
  ring = new Float32Array(WINDOW_SAMPLES);
  filled = 0;
  pending = new Float32Array(0);
  vadFlags = [];
  sinceHop = 0;
  t = 0;
  // seconds of audio consumed
  lastEmbedMs = 0;
  /** Feed any number of samples; returns observations completed by this block (usually 0 or 1). */
  async feed(samples) {
    const obs = [];
    const buf = new Float32Array(this.pending.length + samples.length);
    buf.set(this.pending, 0);
    buf.set(samples, this.pending.length);
    let off = 0;
    while (off + VAD_CHUNK <= buf.length) {
      const chunk = buf.subarray(off, off + VAD_CHUNK);
      off += VAD_CHUNK;
      this.push(chunk);
      const p = await this.vad.prob(chunk);
      this.vadFlags.push(p > VAD_THRESHOLD);
      if (this.vadFlags.length > VAD_PER_WINDOW) this.vadFlags.shift();
      this.t += VAD_CHUNK / 16e3;
      this.sinceHop += VAD_CHUNK;
      if (this.sinceHop >= HOP_SAMPLES && this.filled >= WINDOW_SAMPLES) {
        this.sinceHop -= HOP_SAMPLES;
        obs.push(await this.observe());
      }
    }
    this.pending = buf.slice(off);
    return obs;
  }
  push(chunk) {
    const n = chunk.length;
    this.ring.copyWithin(0, n);
    this.ring.set(chunk, WINDOW_SAMPLES - n);
    this.filled = Math.min(WINDOW_SAMPLES, this.filled + n);
  }
  async observe() {
    const ratio = this.vadFlags.filter(Boolean).length / VAD_PER_WINDOW;
    const speech = ratio >= MIN_SPEECH_RATIO;
    const scores = {};
    if (speech) {
      const t0 = performance.now();
      const e = await this.emb.embed(this.ring);
      this.lastEmbedMs = performance.now() - t0;
      for (const v of this.voiceprints) scores[v.id] = dot(e, v.vec);
    }
    return { t: this.t, speech, scores };
  }
};

// src/engine/decide.ts
var DEFAULT_PARAMS = {
  hopS: 0.5,
  smoothN: 3,
  muteAfterS: 2,
  unmuteAfterS: 3,
  minHoldS: 5,
  defaultThreshold: 0.55,
  thresholds: {}
};
var MuteEngine = class {
  constructor(params, muteSet) {
    this.params = params;
    this.muteSet = muteSet;
  }
  params;
  muteSet;
  hist = /* @__PURE__ */ new Map();
  muted = false;
  target = null;
  candidate = null;
  matchRun = 0;
  otherRun = 0;
  switchedAt = -Infinity;
  last = null;
  thr(id) {
    return this.params.thresholds[id] ?? this.params.defaultThreshold;
  }
  get isMuted() {
    return this.muted;
  }
  reset() {
    this.hist.clear();
    this.muted = false;
    this.target = this.candidate = null;
    this.matchRun = this.otherRun = 0;
    this.switchedAt = -Infinity;
  }
  /** Fail open: unmute immediately. */
  fail(t, reason) {
    const changed = this.muted;
    this.reset();
    return this.last = { t, muted: false, target: null, best: null, bestScore: 0, smoothed: {}, changed, reason: `fail: ${reason}` };
  }
  step(o) {
    const p = this.params;
    if (!o.speech) {
      const prev = this.last;
      return this.last = {
        t: o.t,
        muted: this.muted,
        target: this.target,
        best: prev?.best ?? null,
        bestScore: prev?.bestScore ?? 0,
        smoothed: prev?.smoothed ?? {},
        changed: false,
        reason: "silence"
      };
    }
    const smoothed = {};
    let best = null;
    let bestScore = -Infinity;
    for (const [id, s] of Object.entries(o.scores)) {
      const h = this.hist.get(id) ?? [];
      h.push(s);
      if (h.length > p.smoothN) h.shift();
      this.hist.set(id, h);
      const m = h.reduce((a, b) => a + b, 0) / h.length;
      smoothed[id] = m;
      if (m > bestScore) {
        bestScore = m;
        best = id;
      }
    }
    const match = best !== null && this.muteSet.has(best) && bestScore >= this.thr(best) ? best : null;
    let changed = false;
    let reason;
    if (!this.muted) {
      if (match) {
        if (match === this.candidate) this.matchRun += p.hopS;
        else {
          this.candidate = match;
          this.matchRun = p.hopS;
        }
      } else {
        this.candidate = null;
        this.matchRun = 0;
      }
      const held = o.t - this.switchedAt >= p.minHoldS - 1e-9;
      if (this.candidate && this.matchRun >= p.muteAfterS - 1e-9 && held) {
        this.muted = true;
        this.target = this.candidate;
        this.switchedAt = o.t;
        this.otherRun = 0;
        changed = true;
        reason = `mute: ${this.target} matched ${this.matchRun.toFixed(1)}s`;
      } else {
        reason = match ? `matching ${match} ${this.matchRun.toFixed(1)}s` : "playing";
      }
    } else {
      if (match) {
        this.target = match;
        this.otherRun = 0;
        reason = `muted: ${match}`;
      } else {
        this.otherRun += p.hopS;
        reason = `other speech ${this.otherRun.toFixed(1)}s`;
        if (this.otherRun >= p.unmuteAfterS - 1e-9 && o.t - this.switchedAt >= p.minHoldS - 1e-9) {
          this.muted = false;
          this.target = this.candidate = null;
          this.matchRun = this.otherRun = 0;
          this.switchedAt = o.t;
          changed = true;
          reason = "unmute: other speaker";
        }
      }
    }
    return this.last = { t: o.t, muted: this.muted, target: this.target, best, bestScore, smoothed, changed, reason };
  }
};

// src/shared/settings.ts
var DELAY_S = 3;
var FADE_S = 0.3;

// src/offscreen.ts
I.wasm.wasmPaths = chrome.runtime.getURL("ort/");
I.wasm.numThreads = 1;
var session = null;
var models = null;
var send = (m) => chrome.runtime.sendMessage(m).catch(() => {
});
function status(extra = {}) {
  const d = session?.last;
  return {
    running: !!session,
    muted: d?.muted ?? false,
    target: d?.target ?? null,
    best: d?.best ?? null,
    bestScore: d?.bestScore ?? 0,
    reason: d?.reason ?? "starting",
    embedMs: session?.analyzer.lastEmbedMs ?? 0,
    t: d?.t ?? 0,
    ...extra
  };
}
async function loadModels() {
  if (models) return models;
  const get = async (p) => new Uint8Array(await (await fetch(chrome.runtime.getURL(p))).arrayBuffer());
  const [vadBytes, embBytes, vpDoc] = await Promise.all([
    get("models/silero_vad.onnx"),
    get("models/wespeaker_resnet34_lm.onnx"),
    fetch(chrome.runtime.getURL("voiceprints.json")).then((r) => r.json())
  ]);
  const vad = await SileroVAD.create(ort_wasm_bundle_min_exports, vadBytes);
  const emb = await Embedder.create(ort_wasm_bundle_min_exports, embBytes);
  const vps = vpDoc.speakers.map((s) => ({
    id: s.id,
    vec: Float32Array.from(s.voiceprint)
  }));
  return models = { vad, emb, vps };
}
function engineFor(s) {
  return new MuteEngine({ ...DEFAULT_PARAMS, defaultThreshold: s.threshold }, new Set(s.muted));
}
function applyGain(muted) {
  if (!session) return;
  const { playCtx, gain, settings } = session;
  const now = playCtx.currentTime;
  const at2 = settings.delay && !muted ? now + Math.max(0, DELAY_S - 2) : now;
  gain.gain.cancelScheduledValues(now);
  gain.gain.setValueAtTime(gain.gain.value, now);
  gain.gain.setValueAtTime(gain.gain.value, at2);
  gain.gain.linearRampToValueAtTime(muted ? 0 : 1, at2 + FADE_S);
  const musicDelayMs = (at2 - now) * 1e3;
  setTimeout(() => send({ type: "music", play: muted }), musicDelayMs);
}
async function pump() {
  const s = session;
  if (!s || s.busy) return;
  s.busy = true;
  try {
    while (s.queue.length && session === s) {
      if (s.queue.length > 32) s.queue.splice(0, s.queue.length - 8);
      const block = s.queue.shift();
      for (const o of await s.analyzer.feed(block)) {
        const d = s.engine.step(o);
        s.last = d;
        if (d.changed) applyGain(d.muted);
        send({ type: "status", status: status() });
      }
    }
  } catch (e) {
    const d = s.engine.fail(s.last?.t ?? 0, String(e));
    s.last = d;
    if (d.changed) applyGain(false);
    send({ type: "status", status: status({ error: String(e) }) });
  } finally {
    s.busy = false;
  }
}
async function start(streamId, settings) {
  await stop();
  send({ type: "status", status: { ...status(), reason: "loading models" } });
  const m = await loadModels();
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
    video: false
  });
  const playCtx = new AudioContext();
  const src = playCtx.createMediaStreamSource(stream);
  const delay = playCtx.createDelay(5);
  delay.delayTime.value = settings.delay ? DELAY_S : 0;
  const gain = playCtx.createGain();
  src.connect(delay).connect(gain).connect(playCtx.destination);
  const anaCtx = new AudioContext({ sampleRate: 16e3 });
  await anaCtx.audioWorklet.addModule(chrome.runtime.getURL("tap-worklet.js"));
  const tap = new AudioWorkletNode(anaCtx, "pmute-tap");
  const sink = anaCtx.createGain();
  sink.gain.value = 0;
  anaCtx.createMediaStreamSource(stream).connect(tap).connect(sink).connect(anaCtx.destination);
  m.vad.reset();
  session = {
    stream,
    playCtx,
    anaCtx,
    delay,
    gain,
    settings,
    busy: false,
    queue: [],
    last: null,
    engine: engineFor(settings),
    analyzer: new Analyzer(m.vad, m.emb, m.vps)
  };
  tap.port.onmessage = (ev) => {
    session?.queue.push(ev.data);
    void pump();
  };
  stream.getAudioTracks()[0].addEventListener("ended", () => void stop());
  send({ type: "status", status: status({ reason: "listening" }) });
}
async function stop() {
  const s = session;
  if (!s) return;
  session = null;
  s.stream.getTracks().forEach((t) => t.stop());
  await Promise.allSettled([s.playCtx.close(), s.anaCtx.close()]);
  send({ type: "music", play: false });
  send({ type: "status", status: { ...status(), running: false, muted: false, reason: "stopped" } });
}
function updateSettings(settings) {
  if (!session) return;
  const wasMuted = session.engine.isMuted;
  session.settings = settings;
  session.delay.delayTime.setTargetAtTime(settings.delay ? DELAY_S : 0, session.playCtx.currentTime, 0.1);
  session.engine = engineFor(settings);
  if (wasMuted) applyGain(false);
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "offscreen-start") {
    start(msg.streamId, msg.settings).catch((e) => {
      send({ type: "status", status: { ...status(), running: false, error: String(e), reason: "failed to start" } });
    });
  } else if (msg.type === "offscreen-stop") {
    void stop();
  } else if (msg.type === "offscreen-settings") {
    updateSettings(msg.settings);
  }
});
/*! Bundled license information:

onnxruntime-web/dist/ort.wasm.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.22.0
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
*/
//# sourceMappingURL=offscreen.js.map
